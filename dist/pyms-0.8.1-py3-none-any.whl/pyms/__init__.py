'''PyMS (Python for Mycorrhizal Symbiosis)'''

__version__ = '0.8.1'
